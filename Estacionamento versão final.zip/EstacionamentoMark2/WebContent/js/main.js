
document.getElementById('formulario').addEventListener('submit', cadastrarVeiculo);

function cadastrarVeiculo(e){
	
	var placaVeiculo = document.getElementById('placaVeiculo').value;
	var observacoes = document.getElementById('observacoes').value;
	var horaEntrada = new Date();
	var diaEntrada = new Date();
	var mesEntrada = new Date();
	var anoEntrada = new Date();

	if(!placaVeiculo){
		
		alert("Preencha todos os campos!");
		return false;
	}
	
	if(placaVeiculo=!null){
		alert("Placa do Veiculo: "+placaVeiculo);
	}

	var veiculo = {
		placa: placaVeiculo,
		hora: horaEntrada.getHours(),
		minutos: horaEntrada.getMinutes(),
		segundos: horaEntrada.getSeconds(),
		dia: diaEntrada.getDate(),
		mes: mesEntrada.getMonth(),
		ano: anoEntrada.getUTCFullYear()
	};

	if(localStorage.getItem('patio') === null){
		var veiculos = [];
		veiculos.push(veiculo);
		localStorage.setItem('patio', JSON.stringify(veiculos));
	} else {
		var veiculos = JSON.parse(localStorage.getItem('patio'));
		veiculos.push(veiculo);
		localStorage.setItem('patio', JSON.stringify(veiculos));
	}

	document.getElementById('formulario').reset();

	mostraPatio();

	e.preventDefault();
}

function removeVeiculo(placa){
	var patio = JSON.parse(localStorage.getItem('patio'));
	console.log(patio);

	 for(var i = 0 ; i < patio.length; i++){
		if(patio[i].placa == placa){
			patio.splice(i, 1);
		}
	}

	localStorage.setItem('patio', JSON.stringify(patio));

	mostraPatio();
}

function mostraPatio(){
	var veiculos = JSON.parse(localStorage.getItem('patio'));
	var patioResultado = document.getElementById('resultados');

	patioResultado.innerHTML = '';


	for(var i = 0; i < veiculos.length; i++){
		var placa = veiculos[i].placa;
		var dia = veiculos[i].dia;
		var mes = veiculos[i].mes;
		var ano = veiculos[i].ano;
		var hora = veiculos[i].hora;
		var minutos = veiculos[i].minutos;
		var segundos = veiculos[i].segundos;
		 patioResultado.innerHTML += '<tr><td>'+ placa + '</td>' +
										  '<td>'+ dia + '/' + (mes < 10 ? '0'+mes : mes + 1)+ '/' + ano +'</td>' +
		 							 	  '<td>'+ (hora < 10 ? '0'+hora : hora) + ':' + (minutos < 10 ? '0'+minutos : minutos) + '</td>' +
		 							 	  '<td><button onclick="removeVeiculo(\''+ placa +'\')" class="btn btn-danger">Saída</button></td>'+
		 							 '</tr>';
									 
	}
}


