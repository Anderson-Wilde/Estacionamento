DROP DATABASE IF EXISTS estacionamento;

create database estacionamento;

use estacionamento;

CREATE TABLE cliente (
  id_cliente int(11) NOT NULL AUTO_INCREMENT,
  nome varchar(30) DEFAULT NULL,
  PRIMARY KEY (id_cliente));

CREATE TABLE historico (
  id_historico int(11) NOT NULL AUTO_INCREMENT,
  placa_veiculo varchar(10) DEFAULT NULL,
  hora_entrada varchar(10) DEFAULT NULL,
  hora_saida varchar(10) DEFAULT NULL,
  data varchar(15) DEFAULT NULL,
  observacoes varchar(100) DEFAULT NULL,
  valor varchar(15) DEFAULT NULL,
  PRIMARY KEY (id_historico));

CREATE TABLE ticket_entrada (
  id_entrada int(11) NOT NULL AUTO_INCREMENT,
  hora_entrada time DEFAULT NULL,
  placa_veiculo varchar(10) DEFAULT NULL,
  hora_ini varchar(2) DEFAULT NULL,
  min_ini varchar(2) DEFAULT NULL,
  seg_ini varchar(2) DEFAULT NULL,
  observacoes varchar(100) DEFAULT NULL,
  PRIMARY KEY (id_entrada)
);


